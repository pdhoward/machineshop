# @accelerator/voice-chat

A site assistant visitors can **type to** or **talk to**:
- Typed chat runs on Claude. A voice call runs on OpenAI's realtime model over WebRTC: the browser talks to OpenAI directly with a one-call pass, so the OpenAI key never leaves the server.
- Both use **the site's own skills**, so the assistant can only show and recommend things the site really has.
- Calls are transcribed. The visitor can read and download their transcript, and the owner sees every call from the last 30 days behind an owner code.

Machine Shop (products) and the blog (posts) each had their own copy of this. This package is the shared part; a site supplies only what is its own.

| The package does | The site supplies |
|---|---|
| Chat loop with Claude, tool calls, prompt caching | Its **skills** (JSON Schema) and how to **run** them |
| Voice session, access code, 5-try lockout, 5-minute calls, signed tokens | Its **instructions** (who the assistant is, the rules it follows) |
| Transcripts (cleaned, capped, 30 days), the owner's saved calls | How its **items** look and where they link |
| The launcher, chat panel, call panel, transcript window and owner list (React) | Its colours (a few CSS variables) and words |

## The recipe (Next.js App Router, about 15 minutes)

### 1. Install

The package isn't on a registry yet. Each site carries a packed copy:

```sh
# in accelerator-platform
pnpm --filter @accelerator/voice-chat pack:vendor          # → dist-packages/accelerator-voice-chat-<version>.tgz
# in the site
mkdir -p vendor && cp ../accelerator-platform/dist-packages/accelerator-voice-chat-0.1.0.tgz vendor/
pnpm add ./vendor/accelerator-voice-chat-0.1.0.tgz @anthropic-ai/sdk mongodb   # mongodb only for voice
```

Commit `vendor/`, so the site deploys on its own. To update the package later, pack it again, copy the new file and run `pnpm add` again.

### 2. Settings (environment)

| Setting | For | Notes |
|---|---|---|
| `ANTHROPIC_API_KEY` | chat | `ASSISTANT_MODEL` optional (default `claude-sonnet-5-5`); `ANTHROPIC_WORKSPACE_ID` if the key isn't scoped to one workspace |
| `OPENAI_API_KEY`, `VOICE_MODEL` | voice | e.g. `gpt-realtime` |
| `VOICE_ACCESS_CODE` | voice | The code a visitor types to start a call |
| `VOICE_OWNER_CODE` | voice | The owner's code for saved calls |
| `VOICE_SECRET` | voice | 32+ random characters; signs tokens and hashes device and network IDs |
| `VOICE_MONGODB_URI`, `VOICE_MONGODB_DB` | voice | Its own database and login. `memory` as the URI keeps everything in memory (local tests only) |

Voice switches itself off until every voice setting is present.

### 3. The server (`lib/assistant.ts`)

```ts
import "server-only";
import { createVoiceChat, type Item, type Skill } from "@accelerator/voice-chat/server";

const toItem = (p: Product): Item => ({ id: p.id, title: p.name, href: `/p/${p.id}`, image: p.image, meta: money(p.price), data: p });

export const SKILLS: Skill[] = [
  { name: "search", description: "Search the catalog…", parameters: { type: "object", properties: { query: { type: "string" } }, required: ["query"] } },
  { name: "show", description: "Show these items as cards (max 6).", parameters: { type: "object", properties: { ids: { type: "array", items: { type: "string" } } }, required: ["ids"] } },
];

export const assistant = createVoiceChat({
  skills: SKILLS,
  instructions: (style) => `You are the assistant at Acme…\n- ${style}`,
  async runSkill(name, args) {
    if (name === "search") {
      const found = await search(String(args.query));
      return { output: JSON.stringify(found.map(brief)), found: found.slice(0, 3).map(toItem) };
    }
    const shown = await byIds((args.ids as string[]).slice(0, 6));
    return { output: "Shown.", show: shown.map(toItem) };
  },
  forbidUri: process.env.MONGODB_URI,   // the voice database must not share the main login
});
```

A skill returns `output` (what the model reads), and optionally `show` (cards it chose), `found` (cards a search found) and `open` (a page to take the visitor to).

### 4. Two routes

```ts
// app/api/assistant/route.ts
import { assistant } from "@/lib/assistant";
export const POST = assistant.chat;

// app/api/voice/[...path]/route.ts   (session, tool, transcript and the owner's routes)
import { assistant } from "@/lib/assistant";
export const { GET, POST, DELETE } = assistant.voiceRoutes;
```

### 5. The page

```tsx
// components/site-assistant.tsx
"use client";
import { useRouter } from "next/navigation";
import { Assistant, VoiceChatProvider } from "@accelerator/voice-chat/react";

export function SiteAssistant({ voice }: { voice: boolean }) {
  const router = useRouter();
  return (
    <VoiceChatProvider site={{ navigate: router.push, itemHref: (id) => `/p/${id}`, itemNoun: "Product", filePrefix: "acme-call", copy: { name: "Shop assistant" } }}>
      <Assistant voice={voice} starters={["A gift under $50", "Bright patio lights"]} />
    </VoiceChatProvider>
  );
}
```

Put `<SiteAssistant voice={assistant.voiceReady()} />` in the root layout, and import the styles once:

```css
@import "@accelerator/voice-chat/styles.css";
.vc, .vc-dialog { --vc-accent: var(--brand); --vc-panel: var(--card); --vc-line: var(--border); }
```

The defaults have zero specificity, so your settings always win, in light and dark mode. The variables are `--vc-bg`, `--vc-panel`, `--vc-panel-2`, `--vc-line`, `--vc-ink`, `--vc-fog`, `--vc-mist`, `--vc-accent`, `--vc-accent-2`, `--vc-on-accent`, `--vc-call`, `--vc-call-2`, `--vc-hangup`, `--vc-hangup-2` and `--vc-bad`.

### Optional
- **Your own cards:** `renderItem: (item) => <ProductCard p={item.data as ProductCard} compact />` in the provider.
- **Ask from any page:** `<AskButton prompt="Which drill for a beginner?">Ask about drills</AskButton>`.
- **The owner's saved calls:** a page with `<OwnerTranscripts />` inside the provider. Keep it out of search engines.
- **Spend and faults:** in `chat`, `onUsage(usage)` is called once per reply and `onError(err, model)` on a failed reply. `limited(request)` throttles, and `finish(question, reply)` enforces a rule on every answer.

## The Pages Router (the blog)

```js
// pages/api/voice/[...path].js
import { toNodeHandler } from "@accelerator/voice-chat/server";
import { assistant } from "../../../lib/assistant";
export const config = { api: { bodyParser: false } };
export default toNodeHandler(assistant.voiceRoute);

// pages/api/assistant.js
export const config = { api: { bodyParser: false } };
export default toNodeHandler(assistant.chat);
```

## Older transcripts

Lines saved by the sites' own copies, with speaker `shopper` or `visitor` and `productIds` or `postSlugs`, are read as the user and item IDs, so no migration is needed. The session, attempt and transcript collections, token formats and cookies are the same as before.

## Developing

```sh
pnpm --filter @accelerator/voice-chat test        # the rules and the routes, end to end on an in-memory store
pnpm --filter @accelerator/voice-chat typecheck
pnpm --filter @accelerator/voice-chat build       # dist/
```
